//
//  SecondViewController.swift
//  Product JSON
//
//  Created by user on 3/2/23.
//
import Alamofire
import UIKit

class SecondViewController: UIViewController {

    @IBOutlet weak var category: UILabel!
    
    @IBOutlet weak var rating: UILabel!
    @IBOutlet weak var titleOne: UILabel!
    @IBOutlet weak var desccription: UILabel!
    @IBOutlet weak var indicator: UIActivityIndicatorView!
    @IBOutlet weak var imageView: UIImageView!
    var textPassedOver : String?

    override func viewDidLoad() {
        super.viewDidLoad()
        indicator.startAnimating()
print(textPassedOver)
        fetchFilms(id: textPassedOver ?? "1")
        // Do any additional setup after loading the view.
    }
    
    func fetchFilms(id: String) {
        print(id)
        // 1
        let request = AF.request("https://fakestoreapi.com/products/\(id)", method: .get, parameters: nil )
        // 2
        request.responseJSON { (data) in
         // print(data)
            if(self.parseJsonWeatherStatus(data: request.data!) == false)

            {
                print("no response found")

            }
            
        }
      }
    func parseJsonWeatherStatus(data: Data) ->Bool

    {
        do
        {
            let dictonary = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableContainers) as? NSDictionary
            if let myDictionary = dictonary
            {
                print(myDictionary)
//                imageView = UIImageView(image: myDictionary["image"] as? UIImage)
                print(myDictionary)
                category.text = "Category: \(myDictionary["category"] as! String)"
                titleOne.text = "Title: \(myDictionary["title"] as! String)"
                desccription.text = "Description: \(myDictionary["description"] as! String)"
                if let parsedData = myDictionary["rating"] as? AnyObject
                {
                    let tem = String((parsedData["rate"] as? Double)!)
                    rating.text = "Rating: \(tem)"
                }
                // image view
                if let url = URL(string: myDictionary["image"] as! String) {
                    let task = URLSession.shared.dataTask(with: url) { data, response, error in
                        guard let data = data, error == nil else { return }
                        
                        DispatchQueue.main.async { /// execute on main thread
                            self.imageView.image = UIImage(data: data)
                           
                        }
                    }
                    print("This is task \(task.resume())")
                    indicator.stopAnimating()
                    indicator.hidesWhenStopped = true
                    task.resume()
                }
            }
        } catch
        {
            print("no response found")
            return false
        }
        return true
    }
    
}
